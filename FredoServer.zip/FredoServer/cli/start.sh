#!/bin/bash

while true

do

    clear

    node index.js

    echo

    echo "Restarting server..."

    echo

done
